require("plugins.plugins-setup")

require("core.options")
require("core.keymaps")

