require('lualine').setup({
  optinos = {
    theme = 'tokyonlight'
  }
})
